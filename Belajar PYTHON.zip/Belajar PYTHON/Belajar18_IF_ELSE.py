# if and else

nama = input('Siapa Nama Anda? ')
'''
print Didalam if Hanya Berjalan Jika Kondisi if Sama Dengan Yg Di inputkan.
Jika input Tidak Sama Dengan Kondisi if Maka if akan Dilewati
Dan Mencetak print Yg Didalam else
'''

if nama == "deri":
    print('Wah, Ternyata Selama ini Kamu Orang Yang aku cari😍 ')
else:
    print("Kukira Dia Ternyata Orang Lain😞")
