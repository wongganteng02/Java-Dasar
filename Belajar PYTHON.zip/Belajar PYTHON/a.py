# Buat Struktur / Kolom Dan Syntax Rata Kanan(>) Rata Kiri(<) Tengah(^)
# Beserta Hitungan Berapa Baris Yg Dibutukan Value Kolom
print(f"\n{'KEY':<6} {'Nama':<28} {'Nim':<13} {'Prodi':<12} {'TTL':^11}")
print("-"*72)

a = 'halu'
b = a.join('sayang')
print(b)