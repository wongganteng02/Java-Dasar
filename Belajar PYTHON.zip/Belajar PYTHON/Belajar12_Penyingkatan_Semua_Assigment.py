### Operasi Gabungan / Penyingkatan Semua Assigment

print("\n========OPERASI ARITMATIKA========")
## OPERASI ARITMATIKA
print("\n====(+)====\n")
a = 5 # adalah Assigment
print("Nilai a = ",a)

a += 3 # (Sama Dengan "a = a + 3")
print("Nilai a + 3 = ",a)

print("\n====(-)====\n")
b = 5
print("Nilai b Awal = ",b)
b -= 3 # (Sama Dengan "b = b - 3")
print("Nilai b - 3 = ",b)

print("\n====(*)====\n")
c = 5
print("Nilai c Awal = ",c)
c *= 3 # (Sama Dengan "c = c * 3")
print("Nilai c x 3 = ",c)

print("\n====(/)====\n")
d = 10
print("Nilai d Awal = ",d)
d /= 3 # (Sama Dengan "d = d / 3")
print("Nilai d / 3 = ",round(d, 2))

print("\n====(%)====\n")
e = 10
print("Nilai e Awal = ",e)
e %= 3 # (Sama Dengan "e = e % 3")
print("Nilai e / 3 Sisa Berapa = ",e)

print("\n===(//)===\n")
f = 10
print("Nilai f Awal = ",f)
f //= 3 # (Sama Dengan "f = f // 3")
print("Nilai f Bisa / 3 Berapa kali = ",f)

print("\n===(**)===\n")
g = 10
print("Nilai g Awal = ",g)
g **= 3 # (Sama Dengan "g = g ** 3")
print("Nilai g Pangkat 3 = ",g)

print("\n========OPERASI BITWICE========")

## OPERASI BITWICE
print("\n===OR (|)===\n")
h = True
print("Nilai h Awal = ",h)
h |= False # (Sama Dengan "h = h | False")
print("Nilai h or False = ",h)

print("\n===AND (&)===\n")
i = True
print("Nilai i Awal = ",i)
i &= False # (Sama Dengan "i = i & False")
print("Nilai i and False = ",i)

print("\n===XOR (^)===")
j = True
print("Nilai j Awal = ",j)
j ^= False # (Sama Dengan "j = j ^ False")
print("Nilai j xor False = ",j)


