
## Membuat Fungsi

'''
Fungsi def() Digunakan Untuk Mendefinisikan
Sebuah Fungsi, Yang Bisa Dipanggil Berulang Kali
Dengan Nama Tertentu.
Agar Program Yg Dibuat Lebih Rapi, Dan Mudah Untuk Dimodifikasi
'''
def hello_world():

    print("Hello World")

hello_world()
hello_world()
hello_world()


