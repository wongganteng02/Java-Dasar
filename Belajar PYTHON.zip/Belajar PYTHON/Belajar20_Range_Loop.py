## Loop (Perulangan)

# Loop Dengan List 
print('\n===HASIL LIST []===')
num = [1,2,3,4,5,6,7,8,9,10]

for i in num:
    print(f'{i} I LOVE YOU SAYANG😘')


# Loop Dengan Range
print('\n===HASIL RANGE===')
for i in range(11,20): # Jika Menggunakan range, tanpa Variable Juga Gpp.
    print(f'{i} I LOVE YOU TO DEK..🥰') # Hasil Default range Akan Berkurang 1


# Loop Dengan String
print('\n===HASIL LOOP DENGAN STRING===')
string = "I LIKE YOU"

for i in string:
    print(i)